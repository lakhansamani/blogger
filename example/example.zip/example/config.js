var blogger_username="your_blogger_email";
var credentials={
  url: 'https://scalr.api.appbase.io',
  appname: 'blog',
  username: 'h5aIUPBPO',
  password: '348cee55-1054-4021-ad35-15f93016e876'
}
